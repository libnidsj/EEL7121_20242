#include "pico/stdlib.h"
#include <stdio.h>
#include "hardware/gpio.h"

bool readDone = 0;
bool readCase = 0;
uint64_t startTime = 0;
uint64_t endTime = 0;
const uint pin1 = 14;
const uint pin2 = 15;

void gpio_callback_gettime() {
    endTime = time_us_64();
    readDone = 1;
    irq_set_enabled(IO_IRQ_BANK0, false);
}

int main() {
    stdio_init_all();

    gpio_init(pin1);
    gpio_init(pin2);

    gpio_set_dir(pin1, GPIO_IN);
    gpio_set_dir(pin2, GPIO_IN);

    gpio_set_irq_enabled_with_callback(pin2, GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL, true, &gpio_callback_gettime);
    irq_set_enabled(IO_IRQ_BANK0, false);

    uint pin1Value = 0;
    while (1){
        readDone = 0;

        startTime = time_us_64();

        pin1Value = gpio_get(pin2);

        gpio_set_dir(pin1, GPIO_OUT);

        irq_set_enabled(IO_IRQ_BANK0, true);

        if(pin1Value == 1) {
            gpio_put(pin2, 0);
            readCase = 1;
        } else {
            gpio_put(pin2, 1);
            readCase = 0;
        }   

        while(!readDone);

        uint64_t deltaTimeUs = endTime - startTime;
        if(readCase == 1) {
            // implement equations
        } else {
            // implement equations
        }

        // convert to resistance from voltage
    }
        
}